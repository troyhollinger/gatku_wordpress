<?php

define('QODE_QUICK_LINKS_VERSION', '1.0');
define('QODE_QUICK_LINKS_ABS_PATH', dirname(__FILE__));
define('QODE_QUICK_LINKS_REL_PATH', dirname(plugin_basename(__FILE__ )));